package com.sm.kr.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BootRepository extends JpaRepository<Boot, Integer> {

}
